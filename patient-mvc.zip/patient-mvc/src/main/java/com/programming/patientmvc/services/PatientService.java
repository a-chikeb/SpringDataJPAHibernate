package com.programming.patientmvc.services;


import com.programming.patientmvc.entity.Patient;
import com.programming.patientmvc.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    public Patient save(Patient p){
        return patientRepository.save(p);
    }

    public void update(Integer id,String nom,int age){
        Patient patient = patientRepository.findById(id);
        patient.setNom(nom);
        patient.setAge(age);
        patientRepository.save(patient);
    }

    public List<Patient> findAllPatient(){
        return patientRepository.findAll();
    }

    public Patient findById(Integer id){
        return patientRepository.findById(id);
    }

    public List<Patient> findByAgeGreaterThan(Integer id){
        return patientRepository.findByAgeGreaterThan(id);
    }

    public List<Patient> findByPagination(Integer page){
        Pageable firstPageWithTwoElements = PageRequest.of(page, 2);
        return patientRepository.findAll(firstPageWithTwoElements).toList();
    }

}
