package com.programming.patientmvc.controller;

import com.programming.patientmvc.entity.Patient;
import com.programming.patientmvc.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class PatientController {

    @Autowired
    private PatientRepository patientRepository;

    @GetMapping("/index")
    public String patients(Model model, @RequestParam(name = "page",defaultValue = "0") int page){
        List<Patient> patientList =patientRepository.findAll();
        model.addAttribute("listPatients",patientList);
        return "patients";
    }
}
