package com.programming.patientmvc.repository;

import com.programming.patientmvc.entity.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.awt.print.Pageable;
import java.util.List;

public interface PatientRepository extends JpaRepository<Patient,Long> {

    Patient findById(Integer id);


    List<Patient> findByNomContains(String n);

    List<Patient> findByAgeGreaterThan(int n);

}
