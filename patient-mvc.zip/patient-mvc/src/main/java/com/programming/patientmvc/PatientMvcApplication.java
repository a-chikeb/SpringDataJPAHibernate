package com.programming.patientmvc;

import com.programming.patientmvc.entity.Patient;
import com.programming.patientmvc.repository.PatientRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class PatientMvcApplication {

    public static void main(String[] args) {
        SpringApplication.run(PatientMvcApplication.class, args);
    }

    @Bean
    CommandLineRunner commandLineRunner(PatientRepository patientRepository){
        return args -> {
            patientRepository.save(new Patient("Aymen",30));
            patientRepository.save(new Patient("Youssef",30));
            patientRepository.save(new Patient("Hatim",30));
            patientRepository.save(new Patient("Youssfi",30));
            patientRepository.findAll().forEach(p->{
                System.out.println(p.getNom());
            });
        };
    }
}
